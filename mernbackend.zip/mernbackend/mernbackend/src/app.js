const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

require("./db/conn");
const Register = require("./models/registers");
const { json } = require("express");
const { log } = require("console");

const port = process.env.PORT || 3000;//provide port number to our project

const static_path = path.join(__dirname, "../public" );
const template_path = path.join(__dirname, "../templates/views" );
const partials_path = path.join(__dirname, "../templates/partials" );

app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.use(express.static(static_path));
app.set("view engine", "hbs");
app.set("views", template_path);
hbs.registerPartials(partials_path);


app.get("/", (req, res) => {
    res.render("index")
});

app.get("/contact", (req, res) =>{
    res.render("contact");
})

app.get("/about", (req, res) =>{
    res.render("about");
})

app.get("/shop", (req, res) =>{
    res.render("shop");
})

app.get("/register", (req, res) =>{
    res.render("register");
})
app.get("/login", (req, res) =>{
    res.render("login");
})
app.get("/alogin", (req, res) =>{
    res.render("alogin");
})

app.get("/aabout", (req, res) =>{
    res.render("aabout");
})
app.get("/acontact", (req, res) =>{
    res.render("acontact");
})
app.get("/ashop", (req, res) =>{
    res.render("ashop");
})
app.get("/cart", (req, res) =>{
    res.render("cart");
})

app.get("/privacy", (req, res) =>{
    res.render("privacy");
})

app.get("/terms", (req, res) =>{
    res.render("terms");
})

app.get("/billing", (req, res) =>{
    res.render("billing");
})
app.get("/offers", (req, res) =>{
    res.render("offers");
})
app.get("/elec", (req, res) =>{
    res.render("elec");
})
app.get("/shoes", (req, res) =>{
    res.render("shoes");
})
app.get("/glass", (req, res) =>{
    res.render("glass");
})
app.get("/tee", (req, res) =>{
    res.render("tee");
})
app.get("/watch", (req, res) =>{
    res.render("watch");
})
app.get("/jackets", (req, res) =>{
    res.render("jackets");
})
app.get("/toy", (req, res) =>{
    res.render("toy");
})
app.get("/cars", (req, res) =>{
    res.render("cars");
})
// create a new user in our database
app.post("/register", async (req, res) =>{
    try {

      const password = req.body.password;
      const cpassword = req.body.confirmpassword;

      if(password === cpassword){
        
        const register = new Register({
                firstname: req.body.firstname,
                lastname:req.body.lastname,
                email:req.body.email,
                phone:req.body.phone,
                age:req.body.age,
                password:req.body.password,
                confirmpassword:req.body.confirmpassword    
        })

        console.log("the success part" + register);

        const token = await register.generateAuthToken();
        console.log("the token part" + token);

        const registered = await register.save();
        console.log("the page part" + registered);

        res.status(201).render("alogin");

      }else{
          res.send("password are not matching")
      }
        
    } catch (error) {
        res.status(400).send(Error);
        console.log("the error part page ");
    }
})

app.post("/contact", async (req, res) =>{
    try {
        
        const contact = new Contact({
                firstname: req.body.firstname,
                lastname:req.body.lastname,
                email:req.body.email,
                phone:req.body.phone,
                age:req.body.age,
                password:req.body.password,
                confirmpassword:req.body.confirmpassword    
        })

        console.log("the success part" + contact);

        const token = await contact.generateAuthToken();
        console.log("the token part" + token);

        const contacted = await contact.save();
        console.log("the page part" + contacteded);

        res.status(201).render("alogin");
        
    } catch (error) {
        res.status(400).send(Error);
        console.log("the error part page ");
    }
})


// login check

app.post("/login", async(req, res) =>{
   try {
    
        const email = req.body.email;
        const password = req.body.password;

        const useremail = await Register.findOne({email:email});

        const isMatch = await bcrypt.compare(password, useremail.password);

        const token = await useremail.generateAuthToken();
        console.log("the token part" + token);
       
        if (isMatch) {
          res.render("alogin");
        }else{
           res.send("invalid Password Details"); 
        }
    
   } catch (error) {
       res.status(400).send("invalid login Details")
   }
})


app.listen(port, () => {
    console.log(`server is running at port no ${port}`);
})

