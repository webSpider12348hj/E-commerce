const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { text } = require("stream/consumers");

const userSchema = new mongoose.Schema({
    name : {
        type:String,
        required:true
    },
    email: {
        type:String,
        required:true,
        unique:true
    }, 
    phone: {
        type:Number,
        required:true,
        unique:true
    },
message: {
    type:text,
    required:true,
    unique:false
},
tokens:[{
        token:{
            type:String,
            required:true
        }
    }]
    
})

// generating tokens 
userSchema.methods.generateAuthToken = async function(){
try {
   console.log(this._id);
   const token = jwt.sign({_id:this._id.toString()}, "mynameisvinodbahadurthapayoutuber");
   this.tokens = this.tokens.concat({token:token})
   await this.save();
   return token;
} catch (error) {
   res.send("the error part" + error);
   console.log("the error part" + error);
}
}




// now we need to create a collections

const Contact = new mongoose.model("Contact", userSchema);

module.exports = Contact;